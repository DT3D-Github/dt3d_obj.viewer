// Download full tiny_obj_loader.h from: https://github.com/tinyobjloader/tinyobjloader
