# dt3d_obj_viewer

A minimal 3D OBJ model viewer using C++, OpenGL, GLFW, and tinyobjloader.

## How to Build

- Use Visual Studio or any C++ compiler
- Link against `glfw3.lib`, `opengl32.lib`
- Include `glad` and `tinyobjloader` headers

## Controls

- Hold and drag left mouse to rotate model
